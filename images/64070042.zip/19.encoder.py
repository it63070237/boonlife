import string

def shift(character, n):
    letters = string.ascii_lowercase
    return letters[(letters.index(character) + n) % 26]

def encoder():
    text = input()
    key = int(input())
    cipher = ''.join(shift(x, key) for x in text.lower())

    print(cipher)

encoder()
