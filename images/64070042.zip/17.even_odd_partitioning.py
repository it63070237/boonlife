numbers = []

while True:
    number = input()
    if number == 'END':
        break
    else:
        numbers.append(int(number))

evens = [str(x) for x in numbers if x % 2 == 0]
odds = [str(x) for x in numbers if x % 2 == 1]

print('Even:', ' '.join(evens))
print('Odd:', ' '.join(odds))
