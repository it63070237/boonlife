"""Lucky Seven"""
def lucky():
    """Check last digit"""
    num = int(input())
    if num % 10 == 7:
        print("Lucky!!!")
    else:
        print("No")
lucky()
