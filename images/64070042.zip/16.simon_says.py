THE_WORD = 'Simon says '
repeat = int(input())

sentences = []
for _ in range(repeat):
    sentences.append(input())

simon_sentences = [c.replace(THE_WORD, '', 1) for c in sentences if c.startswith(THE_WORD)]

for c in simon_sentences:
    print(c)
