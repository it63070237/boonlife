def duplication():
    numbers = []
    for _ in range(16):
        numbers.append(int(input()))

    duplicated_numbers = [x for x in set(numbers) if numbers.count(x) > 1]

    for x in sorted(duplicated_numbers):
	    print(x)

duplication()
