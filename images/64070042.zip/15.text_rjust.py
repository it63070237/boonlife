""" Justify Right """
def main():
    """ Justify text by length of paper """
    text = input()
    paper_size = int(input())
    print(text.rjust(paper_size))

main()
