"""Music List"""
def main():
    """Get input from user"""
    music = input().split(', ')
    music_list, check_list = list(), list()
    music.sort(key=len, reverse=True)
    for i in music:
        if i.lower() not in check_list:
            check_list.append(i.lower())
            music_list.append(i)
    for j in range(0, len(music_list)):
        print("{0}.{1}".format(j+1, music_list[j]))

main()
