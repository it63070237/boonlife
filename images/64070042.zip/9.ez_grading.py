"""EZ Grading"""
def main():
    """Grading without condition"""
    grade = "FFFFFDCBAA"
    score = int(input())
    print(grade[score // 10])
main()
