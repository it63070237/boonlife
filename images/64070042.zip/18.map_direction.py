def map_direction():
    text = input()
    mapper = {
        'N': -1j,
        'S': 1j,
        'E': 1,
        'W': -1
    }
    directions = [mapper[x] for x in text]
    paths = [0+0j]
    current_position = 0+0j
    for d in directions:
        current_position += d
        paths.append(current_position)

    ys = [int(p.imag) for p in paths]
    xs = [int(p.real) for p in paths]
    min_y, max_y = min(ys), max(ys)
    min_x, max_x = min(xs), max(xs)

    for y in range(min_y, max_y + 1):
        for x in range(min_x, max_x + 1):
            if complex(x, y) == paths[0]:
                print('B', end=' ')
            elif complex(x, y) == paths[-1]:
                print('E', end=' ')
            elif complex(x, y) in paths:
                print('O', end=' ')
            else:
                print('-', end=' ')
        print()

map_direction()
