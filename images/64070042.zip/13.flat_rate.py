""" Flat rate """
def main():
    """doc"""
    price, down_price, year = int(input()), int(input()), int(input())
    interest = (price-down_price)*(3.25/100)*year
    period = (price-down_price+interest)/(year*12)
    print(int(interest))
    print(int(period))
main()
