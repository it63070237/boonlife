"""The WeakestCharacters"""
def main(letter):
    """Main function"""
    text = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz "
    count = text.count(letter)
    if count <= 0:
        print(letter)
    else:
        index = text.index(letter)
        i = 0
        # loop from 0 until text[i] is letter
        while text[i-1] != letter:
            # print(i, end='')
            print(' '*(index-i), end='')
            for j in range(i + 1):
                print(text[j], end="")
            for j in range(i-1, -1, -1):
                print(text[j], end="")
            print()
            i += 1
        for i in range(index-1, -1, -1):
            # print(i, end='')
            print(' '*(index-i), end='')
            for j in range(i + 1):
                print(text[j], end="")
            for j in range(i-1, -1, -1):
                print(text[j], end="")
            print()

main(input())
