def main():
    numb_list = [i for i in range(1, int(input())+1)]
    for divisor in numb_list:
        for be_divied in numb_list:
            if str(divisor) == "1":
                print("{} is {}".format(str(be_divied)+"/"+str(divisor), int((be_divied / divisor))))
            else:
                print("{} is {}".format(str(be_divied)+"/"+str(divisor), (be_divied / divisor)))
main()
