'''doc'''
def main():
    '''main'''
    num_1 = int(input())
    num_2 = int(input())
    step = (1 or -1)*(num_1 <= num_2)
    prime = 0
    for i in range(num_1, num_2+1, step):
        is_prime = True
        for j in range(2, int(i**0.5) + 1):
            if i % j == 0:
                is_prime = False
                break
        if is_prime and i >= 2:
            prime += 1
    print(prime)
main()
