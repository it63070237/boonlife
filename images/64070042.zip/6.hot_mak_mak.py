"""Hot mak mak"""
def hot():
    temp = int(input())
    if temp < 27:
        print("cold")
    elif temp < 36:
        print("hot")
    elif temp < 41:
        print("hot mak mak")
    else:
        print("die nae nae")
hot()
