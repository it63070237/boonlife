"""Statue"""
def main():
    """Get input from user"""
    statue = int(input())
    line = set()
    for _ in range(statue):
        axis = input().split(',')
        vectorSize = ((int(axis[0])**2)+(int(axis[1])**2))**0.5
        axisx, axisy = int(axis[0])/vectorSize, int(axis[1])/vectorSize
        line.add((axisx, axisy))
    return len(line)

print(main())
