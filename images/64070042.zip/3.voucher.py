"""discount"""
def main(price):
    """sale"""
    print(max(price-300.0, 0.0))
main(float(input()))
