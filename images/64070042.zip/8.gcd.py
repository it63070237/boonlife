"""GCD"""
def main(num1, num2):
    """GCD"""
    while 1:
        if num2 == 0:
            break
        num1, num2 = num2, num1 % num2
    print(num1)
main(int(input()), int(input()))
