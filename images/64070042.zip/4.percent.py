def main():
    """print income"""
    num = float(input())
    per1 = (100/100) * num
    per2 = (200/100) * num
    per3 = (300/100) * num
    print(per1)
    print(per2)
    print(per3)
main()
